#include "../src/control.h"
#include "../src/console.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

static void expect(int condition,const char *label){
    if(!condition){fprintf(stderr,"FAIL: %s\n",label);exit(1);}
    printf("PASS: %s\n",label);
}

int main(void){
    mqtt_client mqtt; char script[700],reason[256];
    memset(&mqtt,0,sizeof(mqtt));
    mqtt.have_machine_status=1; mqtt.machine_status=1;
    mqtt.connected=mqtt.registered=1; mqtt.last_message=time(NULL);
    expect(control_build_script("canvas:reset-all",&mqtt,script,sizeof(script),reason,sizeof(reason)),"Canvas reset accepted idle");
    expect(strlen(script)<CONSOLE_COMMAND_MAX,"Canvas reset fits console transport without truncation");
    for(int i=0;i<4;i++){
        char expected[160];snprintf(expected,sizeof(expected),"CANVAS_SET_FILAMENT_INFO CHANNEL=%d COLOR= detailed_type=\"\" MANUFACTURER= nozzle_max_temp= nozzle_min_temp= TYPE=\"\" CODE=",i);
        expect(strstr(script,expected)!=NULL,"Canvas reset clears each native slot");
    }
    expect(strchr(script,'\n')&&strstr(script,"CANVAS_UNLOAD")==NULL,"Canvas reset does not unload filament");
    expect(!control_build_script("canvas:reset-all",&mqtt,script,100,reason,sizeof(reason)),"Canvas reset rejects truncated batch");
    expect(!control_build_script("canvas:reset-all:extra",&mqtt,script,sizeof(script),reason,sizeof(reason)),"Canvas reset action must match exactly");
    mqtt.machine_status=2;
    expect(!control_build_script("canvas:reset-all",&mqtt,script,sizeof(script),reason,sizeof(reason)),"Canvas reset rejected during printing");
    strcpy(mqtt.print_state,"paused");
    expect(!control_build_script("canvas:reset-all",&mqtt,script,sizeof(script),reason,sizeof(reason)),"Canvas reset rejected during pause");
    mqtt.machine_status=1; mqtt.have_machine_status=0;
    expect(!control_build_script("canvas:reset-all",&mqtt,script,sizeof(script),reason,sizeof(reason)),"Canvas reset rejected without machine status");
    mqtt.have_machine_status=1; mqtt.last_message-=30;
    expect(!control_build_script("canvas:reset-all",&mqtt,script,sizeof(script),reason,sizeof(reason)),"Canvas reset rejected stale");
    mqtt.last_message=time(NULL);mqtt.print_state[0]='\0';
    mqtt.connected=0;
    expect(!control_build_script("canvas:reset-all",&mqtt,script,sizeof(script),reason,sizeof(reason)),"Canvas reset rejected disconnected");
    mqtt.connected=1;mqtt.registered=0;
    expect(!control_build_script("canvas:reset-all",&mqtt,script,sizeof(script),reason,sizeof(reason)),"Canvas reset rejected unregistered");
    mqtt.registered=1;mqtt.last_message=0;
    expect(!control_build_script("canvas:reset-all",&mqtt,script,sizeof(script),reason,sizeof(reason)),"Canvas reset rejected missing timestamp");
    mqtt.last_message=time(NULL)+30;
    expect(!control_build_script("canvas:reset-all",&mqtt,script,sizeof(script),reason,sizeof(reason)),"Canvas reset rejected future timestamp");
    mqtt.last_message=time(NULL);
    expect(control_build_script("canvas:reset-all",&mqtt,script,sizeof(script),reason,sizeof(reason)),"Canvas reset accepted after fresh telemetry recovers");
    expect(control_build_script("canvas:material:1:PLA:2850DF:190:230",&mqtt,script,sizeof(script),reason,sizeof(reason))&&
        !strcmp(script,"CANVAS_SET_FILAMENT_INFO CHANNEL=1 COLOR=0x2850DF detailed_type=\"PLA\" MANUFACTURER=\"Generic\" nozzle_max_temp=230 nozzle_min_temp=190 TYPE=\"PLA\" CODE=Generic"),"Canvas material without a maker is generic");
    expect(control_build_script("canvas:material:1:PLA:2850DF:190:230:PLA Matte:Elegoo",&mqtt,script,sizeof(script),reason,sizeof(reason))&&
        !strcmp(script,"CANVAS_SET_FILAMENT_INFO CHANNEL=1 COLOR=0x2850DF detailed_type=\"PLA Matte\" MANUFACTURER=\"Elegoo\" nozzle_max_temp=230 nozzle_min_temp=190 TYPE=\"PLA\" CODE=Generic"),"Canvas material names a spool's line and maker");
    expect(control_build_script("canvas:material:1:PLA MATTE:2850DF:190:230",&mqtt,script,sizeof(script),reason,sizeof(reason))&&
        strstr(script,"detailed_type=\"PLA MATTE\"")&&strstr(script,"TYPE=\"PLA MATTE\""),"Canvas profile accepts internal spaces and quotes the name");
    const char *bad_materials[]={"canvas:material:1: PLA:2850DF:190:230","canvas:material:1:PLA :2850DF:190:230",
        "canvas:material:1:PLA;M112:2850DF:190:230","canvas:material:1:PLA\nM112:2850DF:190:230",
        "canvas:material:1:PLA\"MATTE:2850DF:190:230","canvas:material:1:12345678901234567:2850DF:190:230",
        "canvas:material:1:PLA:2850DF:190:230junk","canvas:material:1:PLA:2850DF:190:230:PLA Matte",
        "canvas:material:1:PLA:2850DF:190:230:PLA \"x\":Elegoo","canvas:material:1:PLA:2850DF:190:230:PLA Matte:El;ego",
        "canvas:material:1:PLA:2850DF:190:230:PLA Matte:Elegoo:more","canvas:material:1:PLA:2850DF:190:230: PLA:Elegoo",
        "canvas:material:1:PLA:2850DF:190:230:PLA Matte:Elegoo\nM112"};
    for(size_t i=0;i<sizeof(bad_materials)/sizeof(bad_materials[0]);i++)expect(!control_build_script(bad_materials[i],&mqtt,script,sizeof(script),reason,sizeof(reason)),bad_materials[i]);
    expect(control_build_script("heaters:set:205:60",&mqtt,script,sizeof(script),reason,sizeof(reason))&&
        !strcmp(script,"SET_HEATER_TEMPERATURE HEATER=extruder TARGET=205.0\nSET_HEATER_TEMPERATURE HEATER=heater_bed TARGET=60.0"),"temperature targets accepted idle without waiting");
    mqtt.machine_status=2;
    expect(control_build_script("heaters:set:215:65",&mqtt,script,sizeof(script),reason,sizeof(reason)),"temperature targets accepted during print");
    strcpy(mqtt.print_state,"paused");
    expect(control_build_script("heaters:set:210:60",&mqtt,script,sizeof(script),reason,sizeof(reason)),"temperature targets accepted for paused print");
    expect(!control_build_script("preheat:210:60",&mqtt,script,sizeof(script),reason,sizeof(reason)),"preheat remains blocked during print");
    const char *bad_targets[]={"heaters:set:nan:60","heaters:set:210:inf","heaters:set:-1:60","heaters:set:351:60","heaters:set:200:121","heaters:set:200:60junk","heaters:set:200:60\nM112","heaters:set:200"};
    for(size_t i=0;i<sizeof(bad_targets)/sizeof(bad_targets[0]);i++)expect(!control_build_script(bad_targets[i],&mqtt,script,sizeof(script),reason,sizeof(reason)),bad_targets[i]);
    mqtt.last_message-=30;expect(!control_build_script("heaters:set:210:60",&mqtt,script,sizeof(script),reason,sizeof(reason)),"temperature targets rejected stale");mqtt.last_message=time(NULL);
    mqtt.connected=0;expect(!control_build_script("heaters:set:210:60",&mqtt,script,sizeof(script),reason,sizeof(reason)),"temperature targets rejected disconnected");mqtt.connected=1;
    mqtt.registered=0;expect(!control_build_script("heaters:set:210:60",&mqtt,script,sizeof(script),reason,sizeof(reason)),"temperature targets rejected unregistered");mqtt.registered=1;
    mqtt.have_machine_status=0;expect(!control_build_script("heaters:set:210:60",&mqtt,script,sizeof(script),reason,sizeof(reason)),"temperature targets rejected unknown state");mqtt.have_machine_status=1;
    mqtt.machine_status=3;expect(!control_build_script("heaters:set:210:60",&mqtt,script,sizeof(script),reason,sizeof(reason)),"temperature targets rejected during other operation");
    mqtt.machine_status=1; mqtt.print_state[0]=0;
    expect(control_build_script("home:ALL",&mqtt,script,sizeof(script),reason,sizeof(reason))&&strcmp(script,"G28\nSET_HEATER_TEMPERATURE HEATER=extruder TARGET=0.0")==0,"home switches nozzle off when previous target is unavailable");
    mqtt.have_extruder_target=1; mqtt.extruder_target=205.0;
    expect(control_build_script("home:X",&mqtt,script,sizeof(script),reason,sizeof(reason))&&strcmp(script,"G28 X\nSET_HEATER_TEMPERATURE HEATER=extruder TARGET=205.0")==0,"home restores previous nozzle target");
    expect(control_build_script("screws:measure",&mqtt,script,sizeof(script),reason,sizeof(reason)),"screw measurement accepted while idle");
    expect(strstr(script,"M140 S60\nG180 S3\nM190 S60")!=NULL,"screw measurement heats bed and runs stock nozzle cleaning before probing");
    expect(strstr(script,"M190 S60")<strstr(script,"PROBE SAMPLES=3"),"screw measurement waits for 60 C bed before probing");
    expect(strstr(script,"M104 S0\nM140 S0")!=NULL,"screw measurement switches heaters off after probing");
    expect(strstr(script,"G1 X30 Y30 F12000\nPROBE SAMPLES=3\nG1 Z10 F600\nG1 X230 Y30 F12000\nPROBE SAMPLES=3\nG1 Z10 F600\nG1 X230 Y225 F12000\nPROBE SAMPLES=3\nG1 Z10 F600\nG1 X30 Y225 F12000\nPROBE SAMPLES=3\nG1 Z10 F600\nRESTORE_GCODE_STATE NAME=CC2_SCREW_MEASURE\nM104 S0\nM140 S0")!=NULL,"screw measurement uses corrected points and lifts Z before final heater shutdown");
    expect(strstr(script,"G28")==NULL,"screw measurement avoids final homing that clears measured values");
    expect(strstr(script,"TARGET=205.0")==NULL,"screw measurement does not restore stale pre-clean nozzle target");
    {
        char measure[700];
        expect(control_build_script("screws:measure",&mqtt,measure,sizeof(measure),reason,sizeof(reason)),"screw measurement regression remains accepted");
        mqtt.machine_status=2;
        expect(!control_build_script("screws:measure",&mqtt,script,sizeof(script),reason,sizeof(reason)),"screw measurement rejected while printing");
        mqtt.machine_status=1;
        control_screws_reset();
        expect(!control_build_script("screws:tram:probe:FL",&mqtt,script,sizeof(script),reason,sizeof(reason)),"re-probe rejected without a session");
        expect(control_build_script("screws:tram:start",&mqtt,script,sizeof(script),reason,sizeof(reason)),"tram session start accepted while idle");
        expect(strlen(script)<CONSOLE_COMMAND_MAX,"tram start fits the console transport");
        expect(strstr(script,"M140 S60\nG28\nG180 S3\nM190 S60\nG4 P30000\nG90\n")!=NULL,"tram start homes fully, uses the stock bed prep, then settles before probing");
        expect(strstr(script,"G28 Z")==NULL,"tram start does not use Z-only homing");
        expect(strstr(script,"G1 Z10 F600\nG1 X30 Y30 F12000")&&strstr(script,"G1 Z10 F600\nG1 X230 Y30 F12000")&&
               strstr(script,"G1 Z10 F600\nG1 X230 Y225 F12000")&&strstr(script,"G1 Z10 F600\nG1 X30 Y225 F12000"),
               "tram start lifts Z before every XY move and probes the four fixed corners");
        {
            const char *close="RESTORE_GCODE_STATE NAME=CC2_SCREW_TRAM\nM104 S0\nM140 S60\n";
            size_t n=strlen(script),e=strlen(close);
            expect(n>=e&&!strcmp(script+n-e,close),"tram start restores state, switches the nozzle off and keeps the bed at 60 C");
            expect(strstr(script,"PROBE SAMPLES=3")<strstr(script,"M104 S0"),"tram start turns the nozzle off after probing");
        }
        expect(strstr(script,"M140 S0")==NULL,"tram start does not switch the bed off");
        expect(control_screws_session_active(),"tram start arms the session");
        expect(!control_screws_xy_homed(&mqtt),"xy_homed is false until X and Y are reported homed");
        expect(!control_build_script("screws:tram:probe:FL",&mqtt,script,sizeof(script),reason,sizeof(reason)),"re-probe rejected until XY is homed");
        mqtt.have_position=1;strcpy(mqtt.homed_axes,"xyz");
        expect(control_screws_xy_homed(&mqtt),"xy_homed is true once the session has X and Y homed");
        expect(control_build_script("screws:tram:probe:FL",&mqtt,script,sizeof(script),reason,sizeof(reason)),"re-probe FL accepted after session home");
        expect(strlen(script)<CONSOLE_COMMAND_MAX,"tram re-probe fits the console transport");
        expect(strstr(script,"G28 Z\n")!=NULL&&strstr(script,"G28\n")==NULL,"re-probe homes Z only");
        expect(strstr(script,"G4 P30000\n")!=NULL,"re-probe waits the settle constant (G4 P in milliseconds) before probing");
        expect(strstr(script,"G1 Z10 F600\nG1 X30 Y30 F12000\nPROBE SAMPLES=3")!=NULL,"re-probe lifts Z then moves to the FL table point");
        expect(strstr(script,"X230")==NULL&&strstr(script,"Y225")==NULL,"single-corner re-probe does not visit other corners");
        expect(!strstr(script,"30,30")&&!strstr(script,"FL"),"scripts do not echo user-supplied tokens");
        {
            const char *close="RESTORE_GCODE_STATE NAME=CC2_SCREW_TRAM\nM104 S0\nM140 S60\n";
            size_t n=strlen(script),e=strlen(close);
            expect(n>=e&&!strcmp(script+n-e,close),"re-probe restores state and switches the nozzle off after G28 Z");
        }
        expect(control_build_script("screws:tram:probe:FR:2",&mqtt,script,sizeof(script),reason,sizeof(reason)),"probe-twice FR accepted");
        expect(strstr(script,"G1 X230 Y30 F12000\nPROBE SAMPLES=3\nG1 Z10 F600\nPROBE SAMPLES=3\nG1 Z10 F600\n")!=NULL,
               "probe-twice runs a second PROBE at the same corner");
        expect(control_build_script("screws:tram:check",&mqtt,script,sizeof(script),reason,sizeof(reason)),"final four-corner check accepted");
        expect(strstr(script,"G28 Z\n")!=NULL&&strstr(script,"G28\n")==NULL,"final check homes Z only");
        expect(strstr(script,"G1 Z10 F600\nG1 X30 Y30 F12000")&&strstr(script,"G1 Z10 F600\nG1 X230 Y225 F12000"),
               "final check lifts Z before each XY move");
        {
            const char *close="RESTORE_GCODE_STATE NAME=CC2_SCREW_TRAM\nM104 S0\nM140 S60\n";
            size_t n=strlen(script),e=strlen(close);
            expect(n>=e&&!strcmp(script+n-e,close),"final check restores state and switches the nozzle off");
        }
        expect(control_build_script("screws:tram:check:2",&mqtt,script,sizeof(script),reason,sizeof(reason)),"probe-twice four-corner check accepted");
        expect(strlen(script)<CONSOLE_COMMAND_MAX,"probe-twice four-corner check fits the console transport");
        expect(strstr(script,"G28 Z\n")!=NULL&&strstr(script,"G28\n")==NULL,"probe-twice check homes Z only");
        expect(strstr(script,"G4 P30000\n")!=NULL&&!strstr(script,"G4 S"),"probe-twice check waits the settle constant once, in milliseconds");
        {
            const char *p=script;int probes=0;
            while((p=strstr(p,"PROBE SAMPLES=3"))){probes++;p+=15;}
            expect(probes==8,"probe-twice check runs two PROBE commands at each of the four corners");
            const char *close="RESTORE_GCODE_STATE NAME=CC2_SCREW_TRAM\nM104 S0\nM140 S60\n";
            size_t n=strlen(script),e=strlen(close);
            expect(n>=e&&!strcmp(script+n-e,close),"probe-twice check restores state and switches the nozzle off");
        }
        const char *bad_tram[]={"screws:tram:probe:XX","screws:tram:probe:fl","screws:tram:probe:FL:3",
            "screws:tram:probe:30,30","screws:tram:probe:FL:X30","screws:tram:probe:","screws:tram:start:extra",
            "screws:tram:probe:FL\nM112","screws:tram:home","screws:tram:"};
        for(size_t i=0;i<sizeof(bad_tram)/sizeof(bad_tram[0]);i++)
            expect(!control_build_script(bad_tram[i],&mqtt,script,sizeof(script),reason,sizeof(reason)),bad_tram[i]);
        mqtt.machine_status=2;
        expect(!control_build_script("screws:tram:start",&mqtt,script,sizeof(script),reason,sizeof(reason)),"tram start rejected while printing");
        expect(!control_build_script("screws:tram:probe:RL",&mqtt,script,sizeof(script),reason,sizeof(reason)),"re-probe rejected while printing");
        mqtt.machine_status=1;mqtt.last_message=time(NULL)-30;
        expect(!control_build_script("screws:tram:check",&mqtt,script,sizeof(script),reason,sizeof(reason)),"re-probe rejected with stale telemetry");
        mqtt.last_message=time(NULL);mqtt.connected=0;
        expect(!control_build_script("screws:tram:probe:RR",&mqtt,script,sizeof(script),reason,sizeof(reason)),"re-probe rejected when disconnected");
        mqtt.connected=1;
        expect(control_screws_tick(&mqtt,0,0,0,0,time(NULL)+SCREWS_SESSION_TIMEOUT_S+1),"session timeout requests heaters off");
        expect(!control_screws_session_active(),"session invalid after timeout");
        expect(!control_build_script("screws:tram:probe:FL",&mqtt,script,sizeof(script),reason,sizeof(reason)),"re-probe rejected after timeout");
        expect(control_build_script("screws:tram:start",&mqtt,script,sizeof(script),reason,sizeof(reason)),"session can start again after timeout");
        expect(control_build_script("screws:tram:end",&mqtt,script,sizeof(script),reason,sizeof(reason))&&
               !strcmp(script,"M104 S0\nM140 S0"),"tram end switches heaters off");
        expect(strstr(script,"RESTORE_GCODE_STATE")==NULL,"tram end does not restore a consumed gcode state");
        expect(!control_screws_session_active(),"session cleared on end");
        expect(!control_screws_xy_homed(&mqtt),"xy_homed is false after end");
        expect(control_build_script("screws:tram:start",&mqtt,script,sizeof(script),reason,sizeof(reason)),"session start for heaters-off invalidation");
        expect(control_build_script("heaters:off",&mqtt,script,sizeof(script),reason,sizeof(reason)),"heaters-off accepted during a session");
        expect(!control_screws_session_active(),"session invalid after heaters-off");
        expect(control_build_script("screws:tram:start",&mqtt,script,sizeof(script),reason,sizeof(reason)),"session start for emergency invalidation");
        expect(control_build_script("system:emergency_stop",&mqtt,script,sizeof(script),reason,sizeof(reason)),"emergency stop accepted during a session");
        expect(!control_screws_session_active(),"session invalid after emergency stop");
        {
            /* One-shot screws:measure: reported to the history without a session. */
            mqtt.machine_status=1;mqtt.last_message=time(NULL);
            (void)control_screws_take_finished(NULL);
            expect(control_build_script("screws:measure",&mqtt,script,sizeof(script),reason,sizeof(reason)),"one-shot measurement builds");
            control_screws_note_quick(31);
            control_screws_job job={-1,-1,-1,0};
            expect(!control_screws_tick(&mqtt,0,0,31,0,time(NULL))&&!control_screws_take_finished(&job),"a running one-shot measurement is not reported yet");
            (void)control_screws_tick(&mqtt,1,1,31,0,time(NULL));
            expect(control_screws_take_finished(&job)&&job.kind==CONTROL_SCREWS_JOB_QUICK&&job.corner==-1&&!job.twice&&job.started>0,
                   "a completed one-shot measurement is reported once as a quick job");
            control_screws_note_quick(32);
            (void)control_screws_tick(&mqtt,1,0,32,0,time(NULL));
            expect(!control_screws_take_finished(NULL),"a failed one-shot measurement is not recorded");
            control_screws_note_quick(33);
            (void)control_screws_tick(&mqtt,0,0,33,1,time(NULL));
            (void)control_screws_tick(&mqtt,1,1,33,0,time(NULL));
            expect(!control_screws_take_finished(NULL),"an emergency stop drops a pending one-shot measurement");
        }
        expect(control_build_script("screws:tram:start",&mqtt,script,sizeof(script),reason,sizeof(reason)),"session start for console-error invalidation");
        control_screws_note_job(9);
        (void)control_screws_take_finished(NULL);
        expect(control_screws_tick(&mqtt,1,0,9,0,time(NULL)),"failed session job requests heaters off");
        expect(!control_screws_take_finished(NULL),"a failed session job is not recorded in the history");
        expect(!control_screws_session_active(),"session invalid after a failed job");
        expect(control_build_script("screws:tram:start",&mqtt,script,sizeof(script),reason,sizeof(reason)),"session start for lost-homing invalidation");
        mqtt.have_position=1;strcpy(mqtt.homed_axes,"xyz");
        expect(!control_screws_tick(&mqtt,1,1,0,0,time(NULL))&&control_screws_session_active(),"XY homing is recorded after start");
        strcpy(mqtt.homed_axes,"");
        expect(control_screws_tick(&mqtt,0,0,0,0,time(NULL)),"lost XY homing invalidates the session");
        expect(!control_screws_session_active(),"session invalid after XY is unhomed");
        {
            /* On the printer the session's own G28 / G28 Z / PROBE report Manual homing (10)
             * or Auto leveling (5), and the report trails the console job by a poll. */
            time_t t0=time(NULL);
#define TRAM_AT(offset) (mqtt.last_message=t0+(offset),t0+(offset))
            mqtt.machine_status=1;mqtt.have_position=1;strcpy(mqtt.homed_axes,"xyz");mqtt.last_message=t0;
            control_screws_heaters_off_sent();
            expect(control_build_script("screws:tram:start",&mqtt,script,sizeof(script),reason,sizeof(reason)),"session start for homing-state test");
            control_screws_note_action("screws:tram:start");control_screws_note_job(21);
            mqtt.machine_status=10;strcpy(mqtt.homed_axes,"");
            expect(!control_screws_tick(&mqtt,0,0,21,0,TRAM_AT(0))&&control_screws_session_active(),"Manual homing during the session's own G28 keeps the session");
            mqtt.machine_status=5;strcpy(mqtt.homed_axes,"xyz");
            expect(!control_screws_tick(&mqtt,0,0,21,0,TRAM_AT(1))&&control_screws_session_active(),"Auto leveling during the session's own probing keeps the session");
            mqtt.machine_status=10;
            expect(!control_screws_tick(&mqtt,1,1,21,0,TRAM_AT(2))&&control_screws_session_active(),"Manual homing reported just after the job completed is still accepted");
            mqtt.machine_status=1;
            expect(!control_screws_tick(&mqtt,1,1,21,0,TRAM_AT(3))&&control_screws_session_active(),"session idle again after its job");
            {
                control_screws_job job={-1,-1,-1,0};
                expect(control_screws_take_finished(&job)&&job.kind==CONTROL_SCREWS_JOB_START&&job.corner==-1&&!job.twice&&
                       job.started>=t0&&job.started<=time(NULL),"completed session start is reported once to the history");
                expect(!control_screws_take_finished(&job),"a completed job is reported only once");
            }
            mqtt.last_message=time(NULL);
            expect(control_build_script("screws:tram:probe:FR",&mqtt,script,sizeof(script),reason,sizeof(reason)),"re-probe accepted after the start reported Manual homing");
            control_screws_note_action("screws:tram:probe:FR");control_screws_note_job(22);
            mqtt.machine_status=10;strcpy(mqtt.homed_axes,"");
            expect(!control_screws_tick(&mqtt,0,0,22,0,TRAM_AT(4))&&control_screws_session_active(),"Manual homing and a brief XY report gap during the re-probe keep the session");
            mqtt.machine_status=1;strcpy(mqtt.homed_axes,"xyz");
            expect(!control_screws_tick(&mqtt,1,1,22,0,TRAM_AT(40))&&control_screws_session_active(),"re-probe completes");
            {
                control_screws_job job={-1,-1,-1,0};
                expect(control_screws_take_finished(&job)&&job.kind==CONTROL_SCREWS_JOB_PROBE&&job.corner==1&&!job.twice&&job.started>=t0,
                       "completed FR re-probe is reported with its corner and session");
                expect(!strcmp(control_screws_corner_id(job.corner),"FR")&&control_screws_corner_at(229.997,30.002)==1&&
                       control_screws_corner_at(30,225)==3&&control_screws_corner_at(100,100)==-1,"corner IDs and probe positions map to the fixed table");
            }
            expect(!control_screws_heaters_off_pending(),"no heaters-off pending while the session is fine");
            expect(!control_screws_bed_renew_due(t0+40+SCREWS_BED_RENEW_S-1),"bed target not renewed before ten minutes");
            expect(control_screws_bed_renew_due(t0+40+SCREWS_BED_RENEW_S),"bed target renewal due ten minutes after the last job");
            control_screws_bed_renewed(t0+40+SCREWS_BED_RENEW_S,0);
            expect(!control_screws_bed_renew_due(t0+40+SCREWS_BED_RENEW_S+29)&&control_screws_bed_renew_due(t0+40+SCREWS_BED_RENEW_S+30),
                   "a failed bed renewal is retried after 30 s");
            control_screws_bed_renewed(t0+40+SCREWS_BED_RENEW_S+30,1);
            expect(!control_screws_bed_renew_due(t0+40+2*SCREWS_BED_RENEW_S+29)&&control_screws_bed_renew_due(t0+40+2*SCREWS_BED_RENEW_S+30),
                   "a delivered bed renewal waits another ten minutes");
            control_screws_note_job(23);
            expect(!control_screws_bed_renew_due(t0+40+3*SCREWS_BED_RENEW_S),"no bed renewal while the session's own job runs");
            expect(!control_screws_tick(&mqtt,1,1,23,0,TRAM_AT(40))&&control_screws_session_active(),"third job completes");
            mqtt.machine_status=10;
            expect(control_screws_tick(&mqtt,1,1,22,0,TRAM_AT(40+SCREWS_STATUS_GRACE_S+1))&&!control_screws_session_active(),
                   "Manual homing outside the session's own job ends the session");
            expect(control_screws_heaters_off_pending(),"heaters-off stays pending after the session ended");
            mqtt.machine_status=1;
            expect(!control_screws_tick(&mqtt,0,0,0,0,TRAM_AT(60))&&control_screws_heaters_off_pending(),"heaters-off still pending until it is delivered");
            control_screws_note_action("fan:aux:50");
            expect(control_screws_heaters_off_pending(),"an unrelated action keeps the pending heaters-off");
            control_screws_note_action("heaters:set:0:70");
            expect(!control_screws_heaters_off_pending(),"a queued heater action takes the heaters over");
            mqtt.last_message=time(NULL);
            expect(control_build_script("screws:tram:start",&mqtt,script,sizeof(script),reason,sizeof(reason)),"session start for other-state test");
            control_screws_note_action("screws:tram:start");
            mqtt.machine_status=3;
            expect(control_screws_tick(&mqtt,0,0,0,0,time(NULL))&&!control_screws_session_active()&&control_screws_heaters_off_pending(),
                   "another operation (Loading) ends the session and leaves heaters-off pending");
            mqtt.machine_status=2;
            expect(!control_screws_tick(&mqtt,0,0,0,0,time(NULL))&&!control_screws_heaters_off_pending(),"a print takes the heaters over");
            mqtt.machine_status=1;
            expect(control_build_script("screws:tram:start",&mqtt,script,sizeof(script),reason,sizeof(reason)),"session start for pending-clear test");
            mqtt.machine_status=3;
            expect(control_screws_tick(&mqtt,0,0,0,0,time(NULL))&&control_screws_heaters_off_pending(),"pending heaters-off before a new start");
            mqtt.machine_status=1;
            expect(control_screws_tick(&mqtt,0,0,0,0,time(NULL))==0,"no session, nothing to do");
            control_screws_note_action("screws:tram:start");
            expect(!control_screws_heaters_off_pending(),"a new session start clears an old pending heaters-off");
#undef TRAM_AT
            mqtt.last_message=time(NULL);
        }
        expect(control_build_script("screws:measure",&mqtt,script,sizeof(script),reason,sizeof(reason)),"screw measurement still accepted after tram tests");
        expect(!strcmp(script,measure),"one-shot screw measurement script is unchanged");
        expect(strstr(script,"G28")==NULL&&strstr(script,"RESTORE_GCODE_STATE NAME=CC2_SCREW_MEASURE")!=NULL,
               "one-shot screw measurement still avoids G28 and restores state");
        control_screws_reset();
    }
    expect(control_build_script("system:heaters_off",&mqtt,script,sizeof(script),reason,sizeof(reason))&&strcmp(script,"TURN_OFF_HEATERS")==0,"heaters-off command");
    const char *off_aliases[]={"heaters:off","system:heaters_off"};
    for(size_t i=0;i<2;i++) {
        expect(control_build_script(off_aliases[i],&mqtt,script,sizeof(script),reason,sizeof(reason)),"heater shutdown accepted with fresh idle state");
        mqtt.last_message=time(NULL)-30;
        expect(!control_build_script(off_aliases[i],&mqtt,script,sizeof(script),reason,sizeof(reason)),"heater shutdown rejected with stale idle state");
        mqtt.last_message=time(NULL);mqtt.connected=0;
        expect(!control_build_script(off_aliases[i],&mqtt,script,sizeof(script),reason,sizeof(reason)),"heater shutdown rejected when disconnected");
        mqtt.connected=1;mqtt.registered=0;
        expect(!control_build_script(off_aliases[i],&mqtt,script,sizeof(script),reason,sizeof(reason)),"heater shutdown rejected when unregistered");
        mqtt.registered=1;mqtt.have_machine_status=0;
        expect(!control_build_script(off_aliases[i],&mqtt,script,sizeof(script),reason,sizeof(reason)),"heater shutdown rejected with unknown state");
        mqtt.have_machine_status=1;mqtt.machine_status=3;
        expect(!control_build_script(off_aliases[i],&mqtt,script,sizeof(script),reason,sizeof(reason)),"heater shutdown rejected while paused");
        expect(control_build_script("system:emergency_stop",&mqtt,script,sizeof(script),reason,sizeof(reason)),"emergency stop remains available while paused");
        mqtt.machine_status=1;
    }
    expect(control_build_script("system:fans_off",&mqtt,script,sizeof(script),reason,sizeof(reason))&&strstr(script,"M106 P2 S0"),"fans-off command");
    expect(control_build_script("system:emergency_stop",&mqtt,script,sizeof(script),reason,sizeof(reason))&&strcmp(script,"M112")==0,"emergency-stop command");
    mqtt.machine_status=2;
    expect(control_build_script("object:exclude:pièce (2)",&mqtt,script,sizeof(script),reason,sizeof(reason))&&strcmp(script,"EXCLUDE_OBJECT NAME=\"pièce (2)\"")==0,"accented object name and parentheses are quoted safely");
    expect(control_build_script("object:exclude:测试 (1)",&mqtt,script,sizeof(script),reason,sizeof(reason)),"Chinese object name accepted");
    expect(!control_build_script("object:exclude:x\"\nM112",&mqtt,script,sizeof(script),reason,sizeof(reason)),"object command injection rejected");
    expect(!control_build_script("object:exclude:bad\xc0\xaf",&mqtt,script,sizeof(script),reason,sizeof(reason)),"overlong UTF-8 object name rejected");

    expect(!control_build_script("system:fans_off",&mqtt,script,sizeof(script),reason,sizeof(reason)),"fans-off blocked while printing");
    expect(!control_build_script("system:heaters_off",&mqtt,script,sizeof(script),reason,sizeof(reason)),"heaters-off blocked while printing");
    expect(!control_build_script("heaters:off",&mqtt,script,sizeof(script),reason,sizeof(reason)),"heaters-off alias blocked while printing");
    expect(control_build_script("system:emergency_stop",&mqtt,script,sizeof(script),reason,sizeof(reason)),"emergency stop remains available while printing");
    mqtt.connected=mqtt.registered=1;mqtt.last_message=time(NULL);
    strcpy(mqtt.filename,"cube.gcode");strcpy(mqtt.print_state,"printing");
    expect(control_build_script("tune:speed:80",&mqtt,script,sizeof(script),reason,sizeof(reason))&&strcmp(script,"M220 S80")==0,"speed override while printing");
    expect(control_build_script("tune:flow:95",&mqtt,script,sizeof(script),reason,sizeof(reason))&&strcmp(script,"M221 S95")==0,"flow override while printing");
    const char *valid[]={"tune:speed:25","tune:speed:200","tune:speed:100","tune:flow:50","tune:flow:150","tune:flow:100"};
    for(size_t i=0;i<sizeof(valid)/sizeof(valid[0]);i++)expect(control_build_script(valid[i],&mqtt,script,sizeof(script),reason,sizeof(reason)),valid[i]);
    const char *invalid[]={"tune:speed:24","tune:speed:201","tune:flow:49","tune:flow:151","tune:speed:nan","tune:flow:inf","tune:speed:80.5","tune:speed:80junk","tune:flow:95:M112","tune:flow:95\nM112","tune:speed:","tune:other:100","tune:speed:-80","tune:speed:999999999999999999999999999999999999999999999999999"};
    for(size_t i=0;i<sizeof(invalid)/sizeof(invalid[0]);i++)expect(!control_build_script(invalid[i],&mqtt,script,sizeof(script),reason,sizeof(reason)),invalid[i]);
    strcpy(mqtt.print_state,"paused");expect(control_build_script("tune:speed:100",&mqtt,script,sizeof(script),reason,sizeof(reason)),"tuning allowed in pause");
    mqtt.machine_status=1;expect(!control_build_script("tune:speed:100",&mqtt,script,sizeof(script),reason,sizeof(reason)),"tuning blocked idle");mqtt.machine_status=2;
    mqtt.last_message=time(NULL)-30;expect(!control_build_script("tune:speed:100",&mqtt,script,sizeof(script),reason,sizeof(reason)),"tuning blocked stale");mqtt.last_message=time(NULL);
    mqtt.connected=0;expect(!control_build_script("tune:flow:100",&mqtt,script,sizeof(script),reason,sizeof(reason)),"tuning blocked disconnected");mqtt.connected=1;
    mqtt.registered=0;expect(!control_build_script("tune:flow:100",&mqtt,script,sizeof(script),reason,sizeof(reason)),"tuning blocked unregistered");mqtt.registered=1;
    mqtt.filename[0]=0;expect(!control_build_script("tune:speed:100",&mqtt,script,sizeof(script),reason,sizeof(reason)),"tuning blocked without active file");

    /* After homing or calibration the steppers stay energised and keep the
     * board fan running; they are released after ten stationary idle minutes. */
    const time_t limit=CONTROL_IDLE_MOTORS_SECONDS;
    control_idle_motors idle={0};
    control_idle_sample held={.valid=1,.machine_status=1,.print_state="",.board_fan=1.0,.x=52.5,.y=264.0,.z=50.0};
    control_idle_sample s=held;
    expect(!control_idle_motors_due(&idle,&s,1000),"idle release starts its wait");
    expect(!control_idle_motors_due(&idle,&s,1000+limit-1),"idle release waits the full period");
    expect(control_idle_motors_due(&idle,&s,1000+limit),"idle release is due after the full period");
    expect(!control_idle_motors_due(&idle,&s,1000+limit+1)&&!control_idle_motors_due(&idle,&s,1000+3*limit),"idle release is sent once per stationary period");
    s.x+=0.1;
    expect(!control_idle_motors_due(&idle,&s,1000+3*limit+1),"movement after an unconfirmed release restarts the wait");
    expect(control_idle_motors_due(&idle,&s,1000+4*limit+1),"idle release retries after another full period");

    idle=(control_idle_motors){0};s=held;
    expect(!control_idle_motors_due(&idle,&s,0),"idle release armed before movement");
    s.z-=0.2;
    expect(!control_idle_motors_due(&idle,&s,limit-1)&&!control_idle_motors_due(&idle,&s,2*limit-2),"movement restarts the idle wait");
    expect(control_idle_motors_due(&idle,&s,2*limit-1),"idle release counts from the last movement");

    idle=(control_idle_motors){0};s=held;
    expect(!control_idle_motors_due(&idle,&s,0),"idle release armed before steppers are released");
    s.board_fan=0.0;
    expect(!control_idle_motors_due(&idle,&s,limit),"no release once the board fan has stopped");
    s.board_fan=1.0;
    expect(!control_idle_motors_due(&idle,&s,limit+1)&&control_idle_motors_due(&idle,&s,2*limit+1),"re-enabled steppers start a new wait");

    const char *blockers[]={"stale telemetry","printing","paused print","calibrating","console command",
        "nozzle target","bed target","moving"};
    for(int i=0;i<(int)(sizeof(blockers)/sizeof(blockers[0]));i++){
        idle=(control_idle_motors){0};s=held;
        expect(!control_idle_motors_due(&idle,&s,0),"idle release armed before a blocker");
        if(i==0)s.valid=0;
        else if(i==1)s.machine_status=2;
        else if(i==2){s.machine_status=1;s.print_state="paused";}
        else if(i==3)s.machine_status=5;
        else if(i==4)s.console_busy=1;
        else if(i==5)s.nozzle_target=140.0;
        else if(i==6)s.bed_target=60.0;
        else s.velocity=5.0;
        expect(!control_idle_motors_due(&idle,&s,limit)&&!control_idle_motors_due(&idle,&s,3*limit),blockers[i]);
        s=held;
        expect(!control_idle_motors_due(&idle,&s,3*limit+1),"the wait restarts once the blocker clears");
        expect(control_idle_motors_due(&idle,&s,4*limit+1),"release follows a full period after the blocker");
    }
    {
        mqtt_client q;memset(&q,0,sizeof(q));
        q.have_machine_status=1;q.machine_status=1;q.connected=q.registered=1;q.last_message=time(NULL);
        expect(control_build_script("motors:quiet",&q,script,sizeof(script),reason,sizeof(reason)),"quiet motors accepted idle");
        expect(strlen(script)<CONSOLE_COMMAND_MAX,"quiet motors fits the console transport");
        expect(strstr(script,"STEPPER=stepper_x FIELD=en_spreadcycle VALUE=2")&&strstr(script,"STEPPER=stepper_y FIELD=en_spreadcycle VALUE=2")&&
               strstr(script,"STEPPER=stepper_x FIELD=tpwmthrs VALUE=1048576")&&strstr(script,"STEPPER=stepper_y FIELD=tpwmthrs VALUE=1048576"),
               "quiet motors clears en_spreadcycle and tpwmthrs on X and Y without a literal 0");
        expect(strstr(script,"VALUE=0")==NULL,"quiet motors never sends VALUE=0 (refused by the firmware)");
        expect(strstr(script,"DUMP_TMC STEPPER=stepper_x")&&strstr(script,"DUMP_TMC STEPPER=stepper_y"),"quiet motors reads the drivers back");
        expect(control_build_script("motors:normal",&q,script,sizeof(script),reason,sizeof(reason))&&
               strstr(script,"stepper_x FIELD=en_spreadcycle VALUE=1")&&strstr(script,"stepper_y FIELD=en_spreadcycle VALUE=1")&&
               strstr(script,"stepper_y FIELD=tpwmthrs VALUE=1048575"),"normal motors restores SpreadCycle on X and Y");
        expect(strlen(script)<CONSOLE_COMMAND_MAX,"normal motors fits the console transport");
        {
            const char *on_x=NULL,*on_y=NULL,*cap=NULL,*lift=NULL,*wait=NULL;
            expect(control_build_script("motors:quiet",&q,script,sizeof(script),reason,sizeof(reason)),"quiet motors accepted again");
            wait=strstr(script,"M400\n");cap=strstr(script,"SET_VELOCITY_LIMIT VELOCITY=80 ACCEL=2000");
            on_x=strstr(script,"stepper_x FIELD=en_spreadcycle VALUE=2");on_y=strstr(script,"stepper_y FIELD=en_spreadcycle VALUE=2");
            expect(wait==script&&cap&&wait<cap,"quiet motors waits for moves before capping the toolhead");
            expect(cap&&on_x&&on_y&&cap<on_x&&cap<on_y&&cap<strstr(script,"FIELD=tpwmthrs"),
                   "quiet motors caps speed and accel before any StealthChop write");
            expect(strstr(script,"VELOCITY=500")==NULL&&strstr(script,"ACCEL=20000")==NULL,"quiet motors never lifts the cap");
            char normal[700];
            expect(control_build_script("motors:normal",&q,normal,sizeof(normal),reason,sizeof(reason)),"normal motors accepted again");
            lift=strstr(normal,"SET_VELOCITY_LIMIT VELOCITY=500 ACCEL=20000");
            const char *off_x=strstr(normal,"stepper_x FIELD=en_spreadcycle VALUE=1"),*off_y=strstr(normal,"stepper_y FIELD=en_spreadcycle VALUE=1");
            const char *thr_y=strstr(normal,"stepper_y FIELD=tpwmthrs VALUE=1048575");
            expect(lift&&off_x&&off_y&&thr_y&&off_x<lift&&off_y<lift&&thr_y<lift,
                   "normal motors restores SpreadCycle on X and Y before lifting the cap");
            expect(off_x<strstr(normal,"stepper_x FIELD=tpwmthrs")&&strstr(normal,"M400")==NULL,
                   "normal motors enables SpreadCycle before restoring the hybrid threshold");
        }
        {
            int seen=0;
            expect(!control_motor_mode_restore_due(&seen,1,1,"standby"),"quiet idle without a print keeps quiet");
            expect(!control_motor_mode_restore_due(&seen,1,2,"printing")&&seen,"a print in quiet is remembered");
            expect(!control_motor_mode_restore_due(&seen,1,1,"paused"),"a paused print keeps quiet");
            expect(control_motor_mode_restore_due(&seen,1,1,"complete"),"quiet returns to normal when the print ends");
            expect(!control_motor_mode_restore_due(&seen,1,1,"complete"),"the return to normal is requested once");
            seen=1;
            expect(!control_motor_mode_restore_due(&seen,0,1,"complete")&&!seen,"normal mode clears the print memory");
        }
        expect(!control_build_script("motors:quiet:x",&q,script,sizeof(script),reason,sizeof(reason)),"motor mode action must match exactly");
        expect(!control_build_script("motors:quiet",&q,script,200,reason,sizeof(reason)),"motor mode rejects a truncated script");
        q.machine_status=2;
        expect(!control_build_script("motors:quiet",&q,script,sizeof(script),reason,sizeof(reason)),"motor mode rejected while printing");
        q.machine_status=1;q.last_message-=30;
        expect(!control_build_script("motors:normal",&q,script,sizeof(script),reason,sizeof(reason)),"motor mode rejected with stale telemetry");
    }
    return 0;
}
