import { lanRequest, useLanCode } from '@/lib/lan-code'
import { useEffect, useRef, useState } from 'preact/hooks'
import { Card, CardHead } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Dialog, DialogTitle } from '@/components/ui/dialog'
import { PasswordInput } from '@/components/ui/field'
import { ask } from '@/lib/confirm'
import { errText, notify } from '@/lib/api'
import { i18n, t } from '@/lib/i18n'
import { usePoll } from '@/lib/poll'
import { checkUpdates, compatible, newer, refresh, releaseNotes, status, updateCatalog } from '@/lib/updates'

export const Updates = () => {
  usePoll(refresh, 2000)
  const [code, setCode, clearCode] = useLanCode()
  const { data: state, disconnected } = status.use()
  const superseded = state?.phase === 'complete' && !state.busy && newer(state.installed, state.version)
  const phase = superseded ? 'none' : state?.phase
  const language = i18n.use().lang
  const { index, checking } = updateCatalog.use()
  const [working, setWorking] = useState(false),
    [error, setError] = useState('')
  const [file, setFile] = useState<File | null>(null)
  const [showProgress, setShowProgress] = useState(false)
  const mounted = useRef(true),
    selection = useRef(0)
  const release = compatible(index, state?.firmware || '', 'stable')[0]
  const available = release && newer(release.version, state?.installed || '')
  const notes = available ? releaseNotes(release, language) : null
  const busy = working || Boolean(state?.busy)
  const statusText =
    disconnected && busy
      ? t('updates.reconnecting')
      : phase === 'reconciled'
        ? t('updates.up_to_date')
        : phase === 'complete'
          ? t('updates.complete')
          : phase === 'failed' || phase === 'interrupted'
            ? t('updates.failed')
            : phase === 'ready'
              ? t('updates.verified')
              : busy
                ? t('updates.working')
                : t('updates.idle')
  const runCheck = async (force = true) => {
    setError('')
    try {
      await checkUpdates(force)
    } catch (e) {
      if (mounted.current) setError(errText(e))
    }
  }

  useEffect(() => {
    mounted.current = true
    void runCheck(false)
    return () => {
      mounted.current = false
    }
  }, [])
  const prepare = async (local: boolean) => {
    if (!state?.ready || !code.trim() || busy || (local ? !file : !available)) return
    if (!(await ask(t('updates.prepare_confirm')))) return
    const chosen = selection.current
    setWorking(true)
    setError('')
    try {
      if (chosen !== selection.current) return
      await lanRequest(local ? '/api/app-update/upload' : '/api/app-update/download', code, {
        method: 'POST',
        headers: { 'Content-Type': 'application/octet-stream' },
        body: local ? file : release.url,
        signal: AbortSignal.timeout(300000),
      })
      await refresh()
      notify(t('updates.verified'))
    } catch (e) {
      setError(errText(e))
    } finally {
      if (mounted.current) setWorking(false)
    }
  }
  const install = async () => {
    if (
      !state?.ready ||
      state.phase !== 'ready' ||
      !code.trim() ||
      busy ||
      !(await ask(t('updates.install_confirm'), true))
    )
      return
    setWorking(true)
    setError('')
    try {
      await lanRequest('/api/app-update/install', code, {
        method: 'POST',
        body: state.job,
      })
      clearCode()
      notify(t('updates.restarting'))
      await refresh()
    } catch (e) {
      setError(errText(e))
    } finally {
      if (mounted.current) setWorking(false)
    }
  }
  return (
    <Card>
      <CardHead icon="settings" title="updates.title" sub="updates.application_only" />
      <div class="grid gap-4 cc2-sm:grid-cols-2">
        <div>
          <span class="text-muted">{t('updates.installed')}</span>
          <b class="mt-1 block">{state?.installed || '—'}</b>
        </div>
        <p class="text-muted">{t('experiments.channel_stable')}</p>
      </div>
      <div class="my-4 flex flex-wrap items-center gap-3">
        <Button disabled={checking || busy || !state?.enabled} onClick={() => void runCheck()}>
          {t('updates.check')}
        </Button>
        <span>
          {checking
            ? t('updates.checking')
            : available
              ? `${t('updates.available')}: ${release.version}`
              : t('updates.no_update')}
        </span>
      </div>
      {notes?.text && (
        <div class="my-3 text-muted">
          {notes.language !== language && <p class="mb-1 text-sm">{t('updates.notes_in_english')}</p>}
          <p class="whitespace-pre-wrap break-words" lang={notes.language}>
            {notes.text}
          </p>
        </div>
      )}
      {!state?.enabled && <p class="my-3 text-amber">{t('updates.bootstrap')}</p>}
      <p class="my-3 text-sm text-muted">{t('updates.requirements')}</p>
      <label class="block max-w-md" htmlFor="update-lan-code">
        {t('settings.lan_access_code')}
        <PasswordInput
          id="update-lan-code"
          class="mt-1"
          value={code}
          disabled={busy}
          onInput={e => setCode(e.currentTarget.value)}
          autoComplete="off"
        />
      </label>
      <div class="my-4 flex flex-wrap gap-3">
        <Button disabled={!available || !state?.ready || !code.trim() || busy} onClick={() => void prepare(false)}>
          {t('updates.download')}
        </Button>
        <Button
          disabled={state?.phase !== 'ready' || !state.ready || !code.trim() || busy}
          onClick={() => void install()}
        >
          {t('updates.install')}
        </Button>
      </div>
      <details class="border-t border-edge pt-3">
        <summary class="cursor-pointer">{t('updates.local_file')}</summary>
        <input
          class="cc2-update-file my-3 block w-full max-w-md"
          aria-label={t('updates.local_file')}
          type="file"
          accept=".cc2update"
          disabled={busy}
          onChange={e => {
            const selected = e.currentTarget.files?.[0] || null
            selection.current++
            setFile(selected && selected.size >= 1108 && selected.size <= 33555540 ? selected : null)
          }}
        />
        <Button disabled={!file || !state?.ready || !code.trim() || busy} onClick={() => void prepare(true)}>
          {t('updates.verify_file')}
        </Button>
      </details>
      <p class="mt-4">
        {t('updates.status')} {statusText}
      </p>
      <Button class="mt-3" onClick={() => setShowProgress(true)}>
        {t('updates.progress')}
      </Button>
      {showProgress && (
        <Dialog label={t('updates.progress')} onClose={() => setShowProgress(false)}>
          <DialogTitle>{t('updates.progress')}</DialogTitle>
          <p role="status" class="my-3">
            {statusText}
          </p>
          {phase && phase !== 'none' && phase !== 'reconciled' && (
            <p class="mb-3">
              <code>{phase}</code>
            </p>
          )}
          <label class="block">
            {t('updates.progress_log')}
            <textarea
              class="my-2 block w-full font-mono text-sm"
              rows={12}
              readOnly
              value={state?.progress_log || ''}
            />
          </label>
          <Button onClick={() => setShowProgress(false)}>{t('updates.close_progress')}</Button>
        </Dialog>
      )}
      {state?.version && !superseded && (
        <p>
          {t('updates.selected')} {state.version}
        </p>
      )}
      {phase === 'complete' && (
        <Button class="mt-3" onClick={() => location.reload()}>
          {t('updates.reload')}
        </Button>
      )}
      {error && (
        <p class="mt-3 break-words text-red" role="alert">
          {error}
        </p>
      )}
    </Card>
  )
}
