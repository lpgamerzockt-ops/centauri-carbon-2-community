import assert from 'node:assert/strict'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
import { createServer } from 'vite'
import { chromium } from 'playwright'
const root = fileURLToPath(new URL('..', import.meta.url))
const server = await createServer({ root, configFile: path.join(root, 'vite.config.ts'), mode: 'demo', server: { port: 0, host: '127.0.0.1' } })
let browser, machine = 1, homed = 'xyz'
let status = { busy: false, command: '', output: '', completed: false, success: false }
const commands = []
try {
 await server.listen()
 browser = await chromium.launch({headless:true, ...(process.env.CC2_BROWSER_PATH ? { executablePath: process.env.CC2_BROWSER_PATH, args:['--no-sandbox'] } : {})})
 const page = await browser.newPage({ viewport:{width:1440,height:1000} })
 await page.route('**/api/preferences', r=>r.fulfill({json:{language:'en',theme:'dark'}}))
 await page.route('**/api/printer', r=>r.fulfill({json:{connected:true,last_message_age:0,machine:{status:machine},motion:{homed_axes:homed},print:{state:machine===1?'idle':'printing'},extruder:{temperature:25,target:0},heater_bed:{temperature:25,target:0},tuning:{speed_percent:100,flow_percent:100}}}))
 await page.route('**/api/pid', r=>r.fulfill({json:{busy:false,ready:false}}))
 await page.route('**/api/console', r=>r.fulfill({json:status}))
 await page.route('**/api/console/command', r=>{commands.push(r.request().postData());status={busy:true,command:'SHAPER_CALIBRATE',output:'Measuring...',completed:false,success:false};return r.fulfill({status:202,json:{accepted:true}})})
 await page.goto(`${server.resolvedUrls.local[0]}#dashboard`)
 await page.locator('.cc2-quick-actions').waitFor()
 const quickBox = await page.locator('.cc2-quick-actions').boundingBox()
 const rightBox = await page.locator('.cc2-dashboard-primary > div:last-child').boundingBox()
 const frameBox = await page.locator('.cc2-camera-frame').boundingBox()
 assert.ok(Math.abs(quickBox.y + quickBox.height - rightBox.y - rightBox.height) < 2, 'quick actions fill column bottom')
 assert.ok(frameBox.height >= 180, 'camera never collapses below original desktop height')
 assert.equal(await page.locator('.cc2-camera-frame img').count(), 0, 'camera stays stopped during layout test')
 assert.equal(await page.locator('.cc2-tuning input[type=range]').count(),2,'dashboard retains speed and flow only')
 assert.equal(await page.locator('#tune-pressure-advance').count(),0,'Pressure Advance is confined to Control')
 await page.goto(`${server.resolvedUrls.local[0]}#control`)
 const row=page.locator('.cc2-control-calibrations'), start=row.getByRole('button',{name:'Calibrate vibrations',exact:true})
 await page.waitForFunction(()=>!document.querySelector('.cc2-shaper button')?.disabled)
 const boxes=await Promise.all(['.cc2-shaper','.cc2-pid','.cc2-machine'].map(s=>row.locator(s).boundingBox()))
 assert.ok(boxes[0].x<boxes[1].x && boxes[1].x<boxes[2].x)
 const fans=await page.locator('.cc2-fans').boundingBox()
 const z=await page.locator('section').filter({has:page.getByRole('heading',{name:'Live Z Offset',exact:true})}).boundingBox()
 const tuning=await page.locator('.cc2-control-columns .cc2-tuning').boundingBox()
 assert.ok(Math.abs(fans.y-tuning.y)<2,'fans align with print tuning')
 const temperature=await page.locator('section').filter({has:page.getByRole('heading',{name:'Temperatures',exact:true})}).boundingBox()
 assert.ok(Math.abs(temperature.y-z.y)<2,'temperatures align with Z offset')
 const sliders=page.locator('.cc2-control-columns .cc2-tuning')
 assert.equal(await sliders.locator('input[type=range]').count(),3,'Control adds Pressure Advance to speed/flow')
 for(const name of ['Print speed (%)','Flow (%)','Pressure Advance (s)'])
  assert.equal(await sliders.getByRole('slider',{name,exact:true}).count(),1,`one named slider: ${name}`)
 assert.equal(commands.length,0,'opening tuning controls does not start calibration')
 assert.equal(await page.getByText('Enter a value from 0 to 100 and press Enter.',{exact:true}).count(),0,'redundant fan hint removed')
 assert.ok(boxes.every(b=>Math.abs(b.y+b.height-boxes[0].y-boxes[0].height)<2),'desktop card bottoms align')
 await start.click();await page.getByRole('button',{name:'Cancel',exact:true}).click();assert.equal(commands.length,0)
 await start.click();await page.getByRole('button',{name:'Confirm',exact:true}).click()
 await page.waitForFunction(()=>document.querySelector('.cc2-shaper').textContent.includes('Measuring...'))
 assert.deepEqual(commands,['SHAPER_CALIBRATE']);assert.ok(await start.isDisabled())
 status={busy:false,command:'SHAPER_CALIBRATE',output:'Suggested shaper X',completed:true,success:true}
 await page.waitForFunction(()=>document.querySelector('.cc2-shaper').textContent.includes('Suggested shaper X'))
 homed='';await page.waitForFunction(()=>document.querySelector('.cc2-shaper button').disabled)
 machine=2;await page.waitForFunction(()=>document.querySelector('.cc2-shaper').textContent.includes('Available when idle'))
 for(const width of [390,768]){
  await page.setViewportSize({width,height:1000});await page.waitForTimeout(100)
  assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'no horizontal overflow')
  const b=await Promise.all(['.cc2-shaper','.cc2-pid','.cc2-machine'].map(s=>row.locator(s).boundingBox()))
  assert.ok(b[0].y<b[1].y && b[1].y<b[2].y,'narrow row stacks in order')
 }
 console.log('PASS calibration placement desktop/mobile, confirmation, busy/homing/idle guards and output')
} finally {await browser?.close();await server.close()}
